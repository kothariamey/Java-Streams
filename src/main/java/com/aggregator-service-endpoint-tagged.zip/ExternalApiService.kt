package com.example.aggregator.service

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker
import io.github.resilience4j.retry.annotation.Retry
import io.micrometer.core.instrument.MeterRegistry
import io.micrometer.core.instrument.Timer
import kotlinx.coroutines.reactor.awaitSingle
import org.slf4j.LoggerFactory
import org.springframework.stereotype.Service
import org.springframework.web.reactive.function.client.WebClient
import java.time.Duration

@Service
class ExternalApiService(
    private val webClient: WebClient,
    private val meterRegistry: MeterRegistry
) {
    private val logger = LoggerFactory.getLogger(javaClass)

    @CircuitBreaker(name = "externalApiCB", fallbackMethod = "fallback")
    @Retry(name = "externalApiRetry")
    suspend fun fetchDataFromExternalApi(endpoint: String): String {
        return try {
            val start = System.nanoTime()

            val response = webClient.get()
                .uri(endpoint)
                .retrieve()
                .bodyToMono(String::class.java)
                .awaitSingle()

            val duration = Duration.ofNanos(System.nanoTime() - start)

            // record latency with endpoint tag
            Timer.builder("external.api.latency")
                .description("Latency of external API calls")
                .publishPercentileHistogram(true)
                .publishPercentiles(0.5, 0.95, 0.99)
                .tag("endpoint", endpoint)
                .register(meterRegistry)
                .record(duration)

            logger.info("Fetched data from external API [{}] in {} ms", endpoint, duration.toMillis())
            response
        } catch (ex: Exception) {
            logger.error("Error calling external API [{}]: {}", endpoint, ex.message, ex)
            throw ex
        }
    }

    private fun fallback(endpoint: String, ex: Throwable): String {
        logger.warn("Fallback triggered for endpoint [{}] due to {}", endpoint, ex.message)
        return "{}"
    }
}
