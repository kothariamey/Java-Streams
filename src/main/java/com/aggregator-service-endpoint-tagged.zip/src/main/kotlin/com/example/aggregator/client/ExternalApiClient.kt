package com.example.aggregator.client

import com.example.aggregator.domain.dto.ExternalAResponse
import com.example.aggregator.domain.dto.ExternalBResponse
import io.github.resilience4j.kotlin.circuitbreaker.executeSuspendFunction
import io.github.resilience4j.kotlin.retry.executeSuspendFunction
import io.github.resilience4j.kotlin.timelimiter.executeSuspendFunction
import io.github.resilience4j.circuitbreaker.CircuitBreakerRegistry
import io.github.resilience4j.retry.RetryRegistry
import io.github.resilience4j.timelimiter.TimeLimiterRegistry
import kotlinx.coroutines.reactor.awaitSingle
import org.springframework.beans.factory.annotation.Value
import org.springframework.http.MediaType
import org.springframework.stereotype.Component
import org.springframework.web.reactive.function.client.WebClient

@Component
class ExternalApiClient(
    private val webClient: WebClient,
    circuitBreakerRegistry: CircuitBreakerRegistry,
    retryRegistry: RetryRegistry,
    timeLimiterRegistry: TimeLimiterRegistry,
    @Value("\${clients.externalA.baseUrl}") private val externalABase: String,
    @Value("\${clients.externalB.baseUrl}") private val externalBBase: String
) {
    private val cb = circuitBreakerRegistry.circuitBreaker("external")
    private val retry = retryRegistry.retry("external")
    private val tl = timeLimiterRegistry.timeLimiter("external")

    suspend fun fetchFromA(query: String): List<ExternalAResponse> =
        tl.executeSuspendFunction {
            retry.executeSuspendFunction {
                cb.executeSuspendFunction {
                    webClient.get()
                        .uri("$externalABase/search?query={q}", query)
                        .accept(MediaType.APPLICATION_JSON)
                        .retrieve()
                        .bodyToFlux(ExternalAResponse::class.java)
                        .collectList()
                        .awaitSingle()
                }
            }
        }

    suspend fun fetchFromB(query: String): List<ExternalBResponse> =
        tl.executeSuspendFunction {
            retry.executeSuspendFunction {
                cb.executeSuspendFunction {
                    webClient.get()
                        .uri("$externalBBase/find?q={q}", query)
                        .accept(MediaType.APPLICATION_JSON)
                        .retrieve()
                        .bodyToFlux(ExternalBResponse::class.java)
                        .collectList()
                        .awaitSingle()
                }
            }
        }
}
