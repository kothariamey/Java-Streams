package com.example.aggregator.domain.dto

import jakarta.validation.constraints.NotBlank

data class ExternalAResponse(val id: String, val name: String, val score: Int)
data class ExternalBResponse(val id: String, val category: String, val rating: Double)

data class AggregatedItem(
    val id: String,
    val name: String,
    val category: String,
    val blendedScore: Double
)

data class AggregationRequest(
    @field:NotBlank val query: String
)

data class AggregationResponse(
    val items: List<AggregatedItem>
)
