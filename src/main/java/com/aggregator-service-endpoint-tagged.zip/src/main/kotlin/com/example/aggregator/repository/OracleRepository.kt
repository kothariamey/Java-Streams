package com.example.aggregator.repository

import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.reactive.asFlow
import org.springframework.beans.factory.annotation.Qualifier
import org.springframework.data.r2dbc.core.R2dbcEntityTemplate
import org.springframework.r2dbc.core.bind
import org.springframework.stereotype.Repository

data class OracleLookup(val id: String, val category: String)

@Repository
class OracleRepository(@Qualifier("oracleTemplate") private val template: R2dbcEntityTemplate) {
    suspend fun findCategoryById(id: String): String? {
        val sql = "SELECT CATEGORY FROM ORACLE_ITEMS WHERE ID = :id"
        return template.databaseClient.sql(sql).bind("id", id).map { row -> row.get("CATEGORY", String::class.java)!! }.all().asFlow().firstOrNull()
    }
}
