package com.example.aggregator.config

import org.slf4j.MDC
import org.springframework.stereotype.Component
import org.springframework.web.server.ServerWebExchange
import org.springframework.web.server.WebFilter
import org.springframework.web.server.WebFilterChain
import reactor.core.publisher.Mono
import java.util.*

@Component
class TracingFilter : WebFilter {
    override fun filter(exchange: ServerWebExchange, chain: WebFilterChain): Mono<Void> {
        val correlationId = exchange.request.headers.getFirst("X-Correlation-Id") ?: UUID.randomUUID().toString()
        MDC.put("corrId", correlationId)
        exchange.response.headers.add("X-Correlation-Id", correlationId)
        return chain.filter(exchange).doFinally { MDC.remove("corrId") }
    }
}
