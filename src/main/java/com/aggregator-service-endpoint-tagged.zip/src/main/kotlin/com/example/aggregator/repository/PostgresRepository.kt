package com.example.aggregator.repository

import org.springframework.data.repository.kotlin.CoroutineCrudRepository
import org.springframework.stereotype.Repository
import com.example.aggregator.repository.entity.PgItem

@Repository
interface PostgresRepository : CoroutineCrudRepository<PgItem, String>
