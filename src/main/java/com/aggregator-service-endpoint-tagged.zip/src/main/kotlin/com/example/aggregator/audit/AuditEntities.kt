package com.example.aggregator.audit

import org.springframework.data.annotation.Id
import org.springframework.data.relational.core.mapping.Table
import java.time.OffsetDateTime

@Table("audit_event")
data class AuditEvent(
    @Id val id: Long? = null,
    val correlationId: String? = null,
    val milestone: String,
    val message: String? = null,
    val createdAt: OffsetDateTime = OffsetDateTime.now()
)
