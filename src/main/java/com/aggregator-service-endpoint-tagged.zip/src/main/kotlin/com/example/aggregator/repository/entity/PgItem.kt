package com.example.aggregator.repository.entity

import org.springframework.data.annotation.Id
import org.springframework.data.relational.core.mapping.Table

@Table("pg_items")
data class PgItem(
    @Id val id: String,
    val name: String
)
