package com.example.aggregator.service

import com.example.aggregator.audit.AuditService
import com.example.aggregator.client.ExternalApiClient
import com.example.aggregator.domain.dto.AggregatedItem
import com.example.aggregator.domain.dto.AggregationResponse
import com.example.aggregator.repository.OracleRepository
import com.example.aggregator.repository.PostgresRepository
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import org.springframework.cache.annotation.Cacheable
import org.springframework.stereotype.Service
import kotlin.math.round

@Service
class AggregationService(
    private val client: ExternalApiClient,
    private val pgRepo: PostgresRepository,
    private val oracleRepo: OracleRepository,
    private val audit: AuditService
) {
    @Cacheable("aggregation")
    suspend fun aggregate(query: String): AggregationResponse = coroutineScope {
        audit.log("START", "Aggregation started for query=$query")

        val aDeferred = async { client.fetchFromA(query) }
        val bDeferred = async { client.fetchFromB(query) }

        val a = aDeferred.await()
        val b = bDeferred.await()
        audit.log("FETCH_EXTERNAL_DONE", "Fetched A=${a.size}, B=${b.size}")

        // Example: enrich A records with category from Oracle; use Postgres to verify known items
        val items = a.map { aItem ->
            val category = oracleRepo.findCategoryById(aItem.id) ?: b.find { it.id == aItem.id }?.category ?: "UNKNOWN"
            val known = pgRepo.findById(aItem.id)
            val weight = if (known != null) 1.2 else 1.0
            val bRating = b.find { it.id == aItem.id }?.rating ?: 0.0
            val blended = round(((aItem.score * 0.7 + bRating * 10 * 0.3) * weight) * 100.0) / 100.0
            AggregatedItem(id = aItem.id, name = aItem.name, category = category, blendedScore = blended)
        }.sortedByDescending { it.blendedScore }

        audit.log("AGGREGATED", "Produced ${items.size} items")
        AggregationResponse(items)
    }
}
