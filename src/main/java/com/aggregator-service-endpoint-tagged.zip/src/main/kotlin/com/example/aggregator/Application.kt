package com.example.aggregator

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication
import org.springframework.cache.annotation.EnableCaching

@SpringBootApplication
@EnableCaching
class AggregatorApplication

fun main(args: Array<String>) {
    runApplication<AggregatorApplication>(*args)
}
