package com.example.aggregator.audit

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.slf4j.MDC
import org.springframework.stereotype.Service

@Service
class AuditService(private val repo: AuditRepository) {
    suspend fun log(milestone: String, message: String? = null) {
        val corrId = MDC.get("corrId")
        repo.save(AuditEvent(correlationId = corrId, milestone = milestone, message = message))
    }
}
