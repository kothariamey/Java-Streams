package com.example.aggregator.config

import io.r2dbc.spi.ConnectionFactories
import io.r2dbc.spi.ConnectionFactory
import org.springframework.beans.factory.annotation.Qualifier
import org.springframework.beans.factory.annotation.Value
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import org.springframework.data.r2dbc.core.R2dbcEntityTemplate
import org.springframework.data.r2dbc.core.DatabaseClient
import org.springframework.r2dbc.core.bind
import org.springframework.r2dbc.core.DatabaseClient as SpringDatabaseClient

@Configuration
class R2dbcConfig(
    @Value("\${spring.r2dbc.postgres.url}") private val pgUrl: String,
    @Value("\${spring.r2dbc.oracle.url}") private val oracleUrl: String
) {
    @Bean("pgConnectionFactory")
    fun pgConnectionFactory(): ConnectionFactory = ConnectionFactories.get(pgUrl)

    @Bean("oracleConnectionFactory")
    fun oracleConnectionFactory(): ConnectionFactory = ConnectionFactories.get(oracleUrl)

    @Bean("pgTemplate")
    fun pgTemplate(@Qualifier("pgConnectionFactory") cf: ConnectionFactory) = R2dbcEntityTemplate(cf)

    @Bean("oracleTemplate")
    fun oracleTemplate(@Qualifier("oracleConnectionFactory") cf: ConnectionFactory) = R2dbcEntityTemplate(cf)
}
