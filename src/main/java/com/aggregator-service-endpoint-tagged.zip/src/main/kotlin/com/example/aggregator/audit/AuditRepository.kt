package com.example.aggregator.audit

import org.springframework.data.repository.kotlin.CoroutineCrudRepository

interface AuditRepository : CoroutineCrudRepository<AuditEvent, Long>
