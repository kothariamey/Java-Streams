package com.example.aggregator.http

import com.example.aggregator.domain.dto.AggregationRequest
import com.example.aggregator.domain.dto.AggregationResponse
import com.example.aggregator.service.AggregationService
import jakarta.validation.Valid
import org.springframework.http.HttpStatus
import org.springframework.web.bind.annotation.*

@RestController
@RequestMapping("/api/v1")
class ApiController(private val service: AggregationService) {

    @PostMapping("/aggregate")
    @ResponseStatus(HttpStatus.OK)
    suspend fun aggregate(@Valid @RequestBody req: AggregationRequest): AggregationResponse =
        service.aggregate(req.query)
}
