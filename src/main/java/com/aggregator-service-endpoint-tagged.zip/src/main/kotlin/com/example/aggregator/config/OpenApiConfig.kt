package com.example.aggregator.config

import io.swagger.v3.oas.models.ExternalDocumentation
import io.swagger.v3.oas.models.OpenAPI
import io.swagger.v3.oas.models.info.Info
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration

@Configuration
class OpenApiConfig {
    @Bean
    fun api(): OpenAPI = OpenAPI()
        .info(Info().title("Aggregator API").version("v1").description("Aggregates data from external APIs and databases"))
        .externalDocs(ExternalDocumentation().description("Docs").url("https://example.com/docs"))
}
