-- SQL Schedule Table
CREATE TABLE sql_schedule (
    id SERIAL PRIMARY KEY,
    sql TEXT NOT NULL,
    email TEXT NOT NULL,
    schedule_time TIMESTAMPTZ NOT NULL,
    status VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- SQL Execution Audit Table
CREATE TABLE sql_execution_audit (
    id SERIAL PRIMARY KEY,
    schedule_id BIGINT,
    executed_sql TEXT NOT NULL,
    execution_time TIMESTAMPTZ NOT NULL,
    status VARCHAR(20),
    error_message TEXT,
    sent_to_email TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(schedule_id) REFERENCES sql_schedule(id) ON DELETE CASCADE
);
