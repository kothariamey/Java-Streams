package com.example.sqlscheduler.repository;

import com.example.sqlscheduler.entity.SqlExecutionAudit;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface SqlExecutionAuditRepository extends JpaRepository<SqlExecutionAudit, Long> {
    List<SqlExecutionAudit> findByScheduleId(Long scheduleId);
}
