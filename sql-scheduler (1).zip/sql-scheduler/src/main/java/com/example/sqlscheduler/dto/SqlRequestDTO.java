package com.example.sqlscheduler.dto;

public class SqlRequestDTO {
    private String sql;
    private String responseType = "json";

    public String getSql() { return sql; }
    public void setSql(String sql) { this.sql = sql; }

    public String getResponseType() { return responseType; }
    public void setResponseType(String responseType) { this.responseType = responseType; }
}
