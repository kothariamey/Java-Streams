package com.example.sqlscheduler.entity;

import jakarta.persistence.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;
import java.time.ZonedDateTime;

@Entity
public class SqlExecutionAudit {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long scheduleId;

    @Lob
    private String executedSql;

    @Column(columnDefinition = "TIMESTAMPTZ")
    private ZonedDateTime executionTime;

    private String status;
    private String errorMessage;

    private String sentToEmail;

    @CreationTimestamp
    private LocalDateTime createdAt;

    // Getters and Setters
}
