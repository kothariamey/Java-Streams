package com.example.sqlscheduler.repository;

import com.example.sqlscheduler.entity.SqlSchedule;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SqlScheduleRepository extends JpaRepository<SqlSchedule, Long> {}
