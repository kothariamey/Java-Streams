package com.example.sqlscheduler.dto;

import java.time.ZonedDateTime;
import java.util.List;

public class UpdateScheduleRequestDTO {
    private Long id;
    private String sql;
    private List<String> emails;
    private ZonedDateTime scheduleTime;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getSql() { return sql; }
    public void setSql(String sql) { this.sql = sql; }

    public List<String> getEmails() { return emails; }
    public void setEmails(List<String> emails) { this.emails = emails; }

    public ZonedDateTime getScheduleTime() { return scheduleTime; }
    public void setScheduleTime(ZonedDateTime scheduleTime) { this.scheduleTime = scheduleTime; }
}
