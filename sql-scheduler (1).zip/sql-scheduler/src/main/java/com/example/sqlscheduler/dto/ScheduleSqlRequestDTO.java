package com.example.sqlscheduler.dto;

import java.time.ZonedDateTime;

public class ScheduleSqlRequestDTO {
    private String sql;
    private String email;
    private ZonedDateTime scheduleTime;

    public String getSql() { return sql; }
    public void setSql(String sql) { this.sql = sql; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public ZonedDateTime getScheduleTime() { return scheduleTime; }
    public void setScheduleTime(ZonedDateTime scheduleTime) { this.scheduleTime = scheduleTime; }
}
